package jspEx_back;

public class BorderMstBean {
	private int border_code;
	private int border_index;
	private String border_title;
	private String border_writer;
	private String border_date;
	private int border_count;
	
	public int getBorder_code() {
		return border_code;
	}
	public void setBorder_code(int border_code) {
		this.border_code = border_code;
	}
	public int getBorder_index() {
		return border_index;
	}
	public void setBorder_index(int border_index) {
		this.border_index = border_index;
	}
	public String getBorder_title() {
		return border_title;
	}
	public void setBorder_title(String border_title) {
		this.border_title = border_title;
	}
	public String getBorder_writer() {
		return border_writer;
	}
	public void setBorder_writer(String border_writer) {
		this.border_writer = border_writer;
	}
	public String getBorder_date() {
		return border_date;
	}
	public void setBorder_date(String border_date) {
		this.border_date = border_date;
	}
	public int getBorder_count() {
		return border_count;
	}
	public void setBorder_count(int border_count) {
		this.border_count = border_count;
	}
	
	
}
